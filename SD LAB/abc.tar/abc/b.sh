

    Home
    About
    Free eBooks
    Deals
    Donate
    Join TecMint
    Linux Online Courses
    Subscribe
    Linux Hosting
    A-Z Linux Commands

Tecmint: Linux Howtos, Tutorials & Guides

    Linux News
    Linux Distro’s
    Interview Questions
    Programming
    Linux Commands
    Linux Tricks
    Best Linux Tools
    Certifications
    Guides
    Monitoring Tools

    Linux Commands
    5

Manage Files Effectively using head, tail and cat Commands in Linux

by Editor | Published: April 1, 2014 | Last Updated: January 3, 2015
Download Your Free eBooks NOW - 10 Free Linux eBooks for Administrators | 4 Free Shell Scripting eBooks

There are several commands and programs provided by Linux for viewing the contents of file. Working with files is one of the daunting task, most of the computer users be it newbie, regular user, advanced user, developer, admin, etc performs. Working with files effectively and efficiently is an art.
View Content of Files in Linux

Manage Files in Linux

Today, in this article we will be discussing the most popular commands called head, tail and cat, most of us already aware of such commands, but very few of us implement it when needed.
1. head Command

The head command reads the first ten lines of a any given file name. The basic syntax of head command is:

head [options] [file(s)]

For example, the following command will display the first ten lines of the file named ‘/etc/passwd‘.

# head /etc/passwd 

root:x:0:0:root:/root:/bin/bash 
daemon:x:1:1:daemon:/usr/sbin:/bin/sh 
bin:x:2:2:bin:/bin:/bin/sh 
sys:x:3:3:sys:/dev:/bin/sh 
sync:x:4:65534:sync:/bin:/bin/sync 
games:x:5:60:games:/usr/games:/bin/sh 
man:x:6:12:man:/var/cache/man:/bin/sh 
lp:x:7:7:lp:/var/spool/lpd:/bin/sh 
mail:x:8:8:mail:/var/mail:/bin/sh 
news:x:9:9:news:/var/spool/news:/bin/sh

If more than one file is given, head will show the first ten lines of each file separately. For example, the following command will show ten lines of each file.

# head /etc/passwd /etc/shadow

==> /etc/passwd <== root:x:0:0:root:/root:/bin/bash bin:x:1:1:bin:/bin:/sbin/nologin daemon:x:2:2:daemon:/sbin:/sbin/nologin adm:x:3:4:adm:/var/adm:/sbin/nologin lp:x:4:7:lp:/var/spool/lpd:/sbin/nologin sync:x:5:0:sync:/sbin:/bin/sync shutdown:x:6:0:shutdown:/sbin:/sbin/shutdown halt:x:7:0:halt:/sbin:/sbin/halt mail:x:8:12:mail:/var/spool/mail:/sbin/nologin uucp:x:10:14:uucp:/var/spool/uucp:/sbin/nologin ==> /etc/shadow <==
root:$6$85e1:15740:0:99999:7:::
bin:*:15513:0:99999:7:::
daemon:*:15513:0:99999:7:::
adm:*:15513:0:99999:7:::
lp:*:15513:0:99999:7:::
sync:*:15513:0:99999:7:::
shutdown:*:15513:0:99999:7:::
halt:*:15513:0:99999:7:::
mail:*:15513:0:99999:7:::
uucp:*:15513:0:99999:7:::

If it is desired to retrieve more number of lines than the default ten, then ‘-n‘ option is used along with an integer telling the number of lines to be retrieved. For example, the following command will display first 5 lines from the file ‘/var/log/yum.log‘ file.

# head -n5 /var/log/yum.log

Jan 10 00:06:49 Updated: openssl-1.0.1e-16.el6_5.4.i686
Jan 10 00:06:56 Updated: openssl-devel-1.0.1e-16.el6_5.4.i686
Jan 10 00:11:42 Installed: perl-Net-SSLeay-1.35-9.el6.i686
Jan 13 22:13:31 Installed: python-configobj-4.6.0-3.el6.noarch
Jan 13 22:13:36 Installed: terminator-0.95-3.el6.rf.noarch

In fact, there is no need to use ‘-n‘ option. Just the hyphen and specify the integer without spaces to get the same result as the above command.

# head  -5 /var/log/yum.log

Jan 10 00:06:49 Updated: openssl-1.0.1e-16.el6_5.4.i686
Jan 10 00:06:56 Updated: openssl-devel-1.0.1e-16.el6_5.4.i686
Jan 10 00:11:42 Installed: perl-Net-SSLeay-1.35-9.el6.i686
Jan 13 22:13:31 Installed: python-configobj-4.6.0-3.el6.noarch
Jan 13 22:13:36 Installed: terminator-0.95-3.el6.rf.noarch

The head command can also display any desired number of bytes using ‘-c‘ option followed by the number of bytes to be displayed. For example, the following command will display the first 45 bytes of given file.

# head -c45 /var/log/yum.log

Jan 10 00:06:49 Updated: openssl-1.0.1e-16.el

2. tail Command

The tail command allows you to display last ten lines of any text file. Similar to the head command above, tail command also support options  ‘n‘ number of lines and ‘n‘ number of characters.

The basic syntax of tail command is:

# tail [options] [filenames]

For example, the following command will print the last ten lines of a file called ‘access.log‘.

# tail access.log 

1390288226.042      0 172.16.18.71 TCP_DENIED/407 1771 GET http://download.newnext.me/spark.bin? - NONE/- text/html
1390288226.198      0 172.16.16.55 TCP_DENIED/407 1753 CONNECT ent-shasta-rrs.symantec.com:443 - NONE/- text/html
1390288226.210   1182 172.16.20.44 TCP_MISS/200 70872 GET http://mahavat.gov.in/Mahavat/index.jsp pg DIRECT/61.16.223.197 text/html
1390288226.284     70 172.16.20.44 TCP_MISS/304 269 GET http://mahavat.gov.in/Mahavat/i/i-19.gif pg DIRECT/61.16.223.197 -
1390288226.362    570 172.16.176.139 TCP_MISS/200 694 GET http://p4-gayr4vyqxh7oa-3ekrqzjikvrczq44-if-v6exp3-v4.metric.gstatic.com/v6exp3/redir.html pg 
1390288226.402      0 172.16.16.55 TCP_DENIED/407 1753 CONNECT ent-shasta-rrs.symantec.com:443 - NONE/- text/html
1390288226.437    145 172.16.18.53 TCP_DENIED/407 1723 OPTIONS http://172.16.25.252/ - NONE/- text/html
1390288226.445      0 172.16.18.53 TCP_DENIED/407 1723 OPTIONS http://172.16.25.252/ - NONE/- text/html
1390288226.605      0 172.16.16.55 TCP_DENIED/407 1753 CONNECT ent-shasta-rrs.symantec.com:443 - NONE/- text/html
1390288226.808      0 172.16.16.55 TCP_DENIED/407 1753 CONNECT ent-shasta-rrs.symantec.com:443 - NONE/- text/html

If more than one file is provided, tail will print the last ten lines of each file as shown below.

# tail access.log error.log

==> access.log <== 1390288226.042      0 172.16.18.71 TCP_DENIED/407 1771 GET http://download.newnext.me/spark.bin? - NONE/- text/html 1390288226.198      0 172.16.16.55 TCP_DENIED/407 1753 CONNECT ent-shasta-rrs.symantec.com:443 - NONE/- text/html 1390288226.210   1182 172.16.20.44 TCP_MISS/200 70872 GET http://mahavat.gov.in/Mahavat/index.jsp pg DIRECT/61.16.223.197 text/html 1390288226.284     70 172.16.20.44 TCP_MISS/304 269 GET http://mahavat.gov.in/Mahavat/i/i-19.gif pg DIRECT/61.16.223.197 - 1390288226.362    570 172.16.176.139 TCP_MISS/200 694 GET http://p4-gayr4vyqxh7oa-3ekrqzjikvrczq44-if-v6exp3-v4.metric.gstatic.com/v6exp3/redir.html pg  1390288226.402      0 172.16.16.55 TCP_DENIED/407 1753 CONNECT ent-shasta-rrs.symantec.com:443 - NONE/- text/html 1390288226.437    145 172.16.18.53 TCP_DENIED/407 1723 OPTIONS http://172.16.25.252/ - NONE/- text/html 1390288226.445      0 172.16.18.53 TCP_DENIED/407 1723 OPTIONS http://172.16.25.252/ - NONE/- text/html 1390288226.605      0 172.16.16.55 TCP_DENIED/407 1753 CONNECT ent-shasta-rrs.symantec.com:443 - NONE/- text/html 1390288226.808      0 172.16.16.55 TCP_DENIED/407 1753 CONNECT ent-shasta-rrs.symantec.com:443 - NONE/- text/html ==> error_log <==
[Sun Mar 30 03:16:03 2014] [notice] Digest: generating secret for digest authentication ...
[Sun Mar 30 03:16:03 2014] [notice] Digest: done
[Sun Mar 30 03:16:03 2014] [notice] Apache/2.2.15 (Unix) DAV/2 PHP/5.3.3 mod_ssl/2.2.15 OpenSSL/1.0.0-fips configured -- resuming normal operations

Similarly, you can also print the last few lines using the ‘-n‘ option as shown below.

# tail -5 access.log

1390288226.402      0 172.16.16.55 TCP_DENIED/407 1753 CONNECT ent-shasta-rrs.symantec.com:443 - NONE/- text/html
1390288226.437    145 172.16.18.53 TCP_DENIED/407 1723 OPTIONS http://172.16.25.252/ - NONE/- text/html
1390288226.445      0 172.16.18.53 TCP_DENIED/407 1723 OPTIONS http://172.16.25.252/ - NONE/- text/html
1390288226.605      0 172.16.16.55 TCP_DENIED/407 1753 CONNECT ent-shasta-rrs.symantec.com:443 - NONE/- text/html
1390288226.808      0 172.16.16.55 TCP_DENIED/407 1753 CONNECT ent-shasta-rrs.symantec.com:443 - NONE/- text/html

You can also print the number of characters using ‘-c’ argument as shown below.

# tail -c5 access.log

ymantec.com:443 - NONE/- text/html

3. cat Command

The ‘cat‘ command is most widely used, universal tool. It copies standard input to standard output. The command supports scrolling, if text file doesn’t fit the current screen.

The basic syntax of cat command is:

# cat [options] [filenames] [-] [filenames]

The most frequent use of cat is to read the contents of files. All that is required to open a file for reading is to type cat followed by a space and the file name.

# cat /etc/passwd 

root:x:0:0:root:/root:/bin/bash 
daemon:x:1:1:daemon:/usr/sbin:/bin/sh 
bin:x:2:2:bin:/bin:/bin/sh 
sys:x:3:3:sys:/dev:/bin/sh 
sync:x:4:65534:sync:/bin:/bin/sync 
games:x:5:60:games:/usr/games:/bin/sh 
man:x:6:12:man:/var/cache/man:/bin/sh 
lp:x:7:7:lp:/var/spool/lpd:/bin/sh 
…

The cat command also used to concatenate number of files together.

# echo 'Hi Tecmint-Team' > 1 
# echo 'Keep connected' > 2 
# echo 'Share your thought' > 3 
# echo 'connect us tecmint.com@gmail.com' > 4

# cat 1 2 3 4 > 5

# cat 5 

Hi Tecmint-Team 
Keep connected 
Share your thought 
connect us tecmint.com@gmail.com

It can be also used to create files as well. It is achieved by executing cat followed by the output redirection operator and the file name to be created.

# cat > tecmint.txt

Tecmint is the only website fully dedicated to Linux.

We can have custom end maker for ‘cat’ command. Here it is implemented.

# cat > test.txt << end 

I am Avishek 
Here i am writing this post 
Hope your are enjoying 
end

# cat test.txt 

I am Avishek 
Here i am writing this post 
Hope your are enjoying

Never underestimate the power of  ‘cat’ command and can be useful for copying files.

# cat avi.txt

I am a Programmer by birth and Admin by profession

# cat avi.txt > avi1.txt

# cat avi1.txt

I am a Programmer by birth and Admin by profession

Now what’s the opposite of cat? Yeah it’s ‘tac‘. ‘tac‘ is a command under Linux. It is better to show an example of ‘tac’ than to talk anything about it.

Create a text file with the names of all the month, such that one word appears on a line.

# cat month

January
February
March
April
May
June
July
August
September
October
November
December

# tac month

December
November
October
September
August
July
June
May
April
March
February
January

For more examples of cat command usage, refer to the 13 cat Command Usage

That’s all for now. I’ll be here again with another Interesting Article, worth Knowing. Till then stay tuned and connected to Tecmint. Don’t forget to provide us with your valuable feedback in our comment section.
Share
+
0
0
0
Ask Anything
If You Appreciate What We Do Here On TecMint, You Should Consider:

    Stay Connected to: Twitter | Facebook | Google Plus
    Subscribe to our email updates: Sign Up Now
    Get your own self-hosted blog with a Free Domain at ($3.45/month).
    Become a Supporter - Make a contribution via PayPal
    Support us by purchasing our premium books in PDF format.
    Support us by taking our online Linux courses

We are thankful for your never ending support.

Tags: head commandtail command
RedHat RHCE and RHCSA Certification Book
Linux Foundation LFCS and LFCE Certification Preparation Guide

    Next story
    Nautilus Terminal: An Embedded Terminal for Nautilus File Browser in GNOME
    Previous story
    Fun in Linux Terminal – Play with Word and Character Counts

You may also like...

    Cat Command Syntax Highlighting
    2
    ccat – Show ‘cat Command’ Output with Syntax Highlighting or Colorizing

    11 Dec, 2017
    Disable Lock Certain Package Updates Yum
    0
    4 Ways to Disable/Lock Certain Package Updates Using Yum Command

    11 Jan, 2016
    Rsync Files Over SSH Non-standard Port
    6
    How to Sync Files/Directories Using Rsync with Non-standard SSH Port

    10 Dec, 2015

5 Responses

    Comments5
    Pingbacks0

    Philippe Moisan
    January 5, 2019 at 2:32 pm

    Hello,

    May I suggest you also talk about the “less” command. I myself use very often, to go up and down in a file, and with search options too. It also has the g and G options to go directly to beginning or end of file.

    Also, you might mention the “view” command, the read-only version of vi, which can be very useful to look at a file with all the vi search options, without risk, since you can’t edit it.

    Thanks for a great series of articles.

    Philippe Moisan
    Reply
    silambarasan
    January 4, 2019 at 7:25 am

    thanks, bro!
    Reply
    sameer
    January 20, 2017 at 6:45 am

    Thanks. It was very useful
    Reply
    kiran varma
    April 4, 2014 at 7:40 pm

    Thank you Avinash really liked it.
    Reply
    Mike
    April 2, 2014 at 11:25 pm

    Thanks!
    Reply

Got something to say? Join the discussion.

Comment

Name *

Email *

Website

Notify me of followup comments via e-mail. You can also subscribe without commenting.

This site uses Akismet to reduce spam. Learn how your comment data is processed.
I TecMint :

BEGINNER'S GUIDE FOR LINUX Start learning Linux in minutes
Vi/Vim Editor BEGINNER'S GUIDE Learn vi/vim as a Full Text Editor
Linux Foundation Certification Exam Study Guide to LFCS and LFCE

    How to Add Linux Host to Nagios Monitoring Server Using NRPE Plugin

    How to Install Nagios 4.3.4 on RHEL, CentOS and Fedora

    Install Cacti (Network Monitoring) on RHEL/CentOS 7.x/6.x/5.x and Fedora 24-12

    Google Chrome 70 Released – Install on RHEL/CentOS and Fedora

    How to Install Ubuntu 16.10/16.04 Alongside With Windows 10 or 8 in Dual-Boot

RedHat RHCSA and RHCE Certification Exam Study Ebook

Linux System Administrator Bundle with 7-Courses (96% off)

Add to Cart - $69

Ending In: 3 days

Computer Hacker Professional Certification Course (96% Off)

Add to Cart - $59

Ending In: 4 days
Linux eBooks

    Introducing Learn Linux In One Week and Go from Zero to Hero
    RedHat RHCE/RHCSA Certification Preparation Guide
    Linux Foundations LFCS/LFCE Certification Guide
    Postfix Mail Server Setup Guide for Linux
    Ansible Setup Guide for Linux
    Django Setup Guide for Linux
    Awk Getting Started Guide for Beginners
    Citrix XenServer Setup Guide for Linux

Never Miss Any Linux Tutorials, Guides, Tips and Free eBooks

Join Our Community Of 150,000+ Linux Lovers and get a weekly newsletter in your inbox

YES! SIGN ME UP



Linux Monitoring Tools

    Hegemon – A Modular System Monitoring Tool for Linux

    How to Install ‘atop’ to Monitor Logging Activity of Linux System Processes

    13 Linux Network Configuration and Troubleshooting Commands

    Perf- A Performance Monitoring and Analysis Tool for Linux

    How to Install Nagios 4.3.4 on RHEL, CentOS and Fedora

Linux Interview Questions

    Practical Interview Questions and Answers on Linux Shell Scripting

    Basic Linux Interview Questions and Answers – Part II

    10 Advance VsFTP Interview Questions and Answers – Part II

    10 Useful Interview Questions and Answers on Linux Commands

    10 Basic Interview Questions and Answers on Linux Networking – Part 1

Open Source Tools

    6 Best Calendar Apps for Linux Desktop

    Top 6 Partition Managers (CLI + GUI) for Linux

    5 Best Modern Linux ‘init’ Systems (1992-2015)

    9 Best Twitter Clients for Linux That You Will Love to Use

    5 Most Frequently Used Open Source Shells for Linux

    Donate to TecMint
    Contact Us
    Advertise on TecMint
    Linux Services
    Copyright Policy
    Privacy Policy
    Career
    Sponsored Post

Tecmint: Linux Howtos, Tutorials & Guides © 2019. All Rights Reserved.

The material in this site cannot be republished either online or offline, without our permission.

    25 Useful Basic Commands of APT-GET and APT-CACHE


